# backup 4/25 17:34 after merge from main

```
 [{'SCHEMA_NAME': 'mysql'}, {'SCHEMA_NAME': 'information_schema'}, {'SCHEMA_NAME': 'performance_schema'}, {'SCHEMA_NAME': 'sys'}, {'SCHEMA_NAME': 'openmodelhub'}]
{'err': 0, 'sql': 'SELECT schema_name\nFROM information_schema.schemata;', 'sql_res': [{'SCHEMA_NAME': 'mysql'}, {'SCHEMA_NAME': 'information_schema'}, {'SCHEMA_NAME': 'performance_schema'}, {'SCHEMA_NAME': 'sys'}, {'SCHEMA_NAME': 'openmodelhub'}]}
```